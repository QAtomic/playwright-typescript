function GetElqContentPersonalizationValue(strDataField){ var strTemp = '';        if(strDataField == 'V_Total_Pages' || strDataField == 'Total_Pages'){strTemp = '0';}
        if(strDataField == 'V_Total_Time' || strDataField == 'Total_Time'){strTemp = '0';}
        if(strDataField == 'V_Total_Visits' || strDataField == 'Total_Visits'){strTemp = '0';}
	return strTemp; } if (this.SetElqContent){ SetElqContent(); }